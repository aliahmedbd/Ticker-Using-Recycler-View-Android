package com.example.bs058.myapplication;

public interface OnItemClickListener {
    void onItemClick(StockListModel item);
    void onChildItemClick(StockListModel item);
}